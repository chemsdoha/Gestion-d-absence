# GestionAbsence
Mon projet académique réalisé en PHP native lors de ma première année en cycle d'ingénieur. L' application web créée permet de gérer les absences des étudiants.

![Image description](/Home.JPG)

<br><br><br>

## Outils et technologies de développement utilisés

### Langages de programmation
L'application est développée en back-office avec le langage serveur PHP. Tandis qu'en front-office avec Javascript et CSS (Framework Bootstrap v3.3.7).

### Base de données 
La gestion de la base de donnée est gérée à l'aide du système MySQL. <br>
L'interface pour accéder à la base de données est définie avec l'extension PDO (PHP Data Objects).
